# -*- coding: utf-8 -*-
"""
Created on Fri Jun  9 14:05:06 2023

@author: gbm
"""

import torch

import mlflow



run_id = "your ml_save/SMCL_SVM/0/folder name"
metric_name = "loss"


# last results in logging
run = mlflow.get_run(run_id)
metrics = run.data.metrics
tags = run.data.tags
params = run.data.params

# reading all results 
client = mlflow.tracking.MlflowClient()
result = client.get_metric_history(run_id, metric_name)

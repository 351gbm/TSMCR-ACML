import torch
import torch.nn as nn
#from src.losses.loss_functions import ClassifLoss

import torch.nn.functional as F

class ContrastiveLoss(nn.Module):
    """Basic generator GAN loss """

    def __init__(self) -> None:
        super().__init__()

    def __call__(self, pro_repre: torch.Tensor, lambda_d: torch.Tensor) -> float:
        """encoder loss
        D(a,p) + hinge(lambda - D(a,n1))^2 + hinge(lambda - D(a,n2))^2
        
        resonable lambda is less than 1 and greater than 0，
        larger value, the greater negative samples penatly  
        noting: if necessary, lambda may be larger than 1 

  
        Args:
            projection representations (torch.Tensor): N x dim，(4 x dim)
                                      4-tuple [anchor, postive, negative1, negative2]
            
            lambda_d: 1 x 2
        Returns:
            float: contrastive loss value
        """
        # threshold value list
        lambda_d = lambda_d
        
        anchor = pro_repre[0]
        contrastive_sample = pro_repre[1:]
        anchor = anchor.expand_as(contrastive_sample)
        
        # calculate the square of distance between anchor and other samples
        criterior = nn.MSELoss(reduction='none')
        outputs = criterior(anchor, contrastive_sample)
        outputs = outputs.sum(dim=1)
        
        # 
        loss = {}
        loss["postive_pairs"] = outputs[0]
        loss["negative_pairs1"] = outputs[1]
        loss["negative_pairs2"] = outputs[2]        
        
        
        # positive pairs are outputs[0]
        
        # negative pairs need to calculate the hinge loss
        tmp_outputs = lambda_d - outputs[1:]
        tmp_outputs[tmp_outputs<0] = 0
        tmp_outputs = tmp_outputs * tmp_outputs
        
        # unavailable due to inplace,
        #outputs[1:] = lambda_d - outputs[1:]
        #outputs[outputs<0] = 0
        #outputs[1:] = outputs[1:] * outputs[1:] #.pow(2)
        
        #outputs[1:] = tmp_outputs
        
        
        # sum and mean仅相差一个常数差异
        # sum
        loss_total = outputs[0] + tmp_outputs.sum()
        
        #  mean
        # loss_total = torch.mean(outputs)
        

        loss["contrastive"] = loss_total
        
        return loss
    
    
class HypersphereLoss(nn.Module):
    """Basic generator GAN loss """

    def __init__(self) -> None:
        super().__init__()

    def __call__(self, pro_repre: torch.Tensor, miu_hypersphere: torch.Tensor) -> float:
        """encoder hypershpere loss
         [L2(x) - eta]^2
        Args:
            projection representations (torch.Tensor): N x dim，(4 x dim)
                                  4-tuple [anchor, postive, negative1, negative2]
            
            miu_hypersphere: 1 x 1  for hypersherical radius
        Returns:
            float: hypershpere loss value
        """
        # HC radius: r1 and r2
        miu_hypersphere = miu_hypersphere
        
        tuple_pairs = pro_repre
        
        # mean((L2(x) - miu) ^ 2)
        tmp_norm = torch.norm(tuple_pairs, dim=1) # L2 norm
        tmp_norm = tmp_norm - miu_hypersphere # 
        tmp_norm = torch.mean(tmp_norm * tmp_norm)
        
        
        loss = {}
        loss["hypersphere_loss"] = tmp_norm

        return loss    

    
class SMCLLoss(nn.Module):
    """Loss function for a tuple [anchor, postive,negative1,negative2]

    Args:
        
    """

    def __init__(self, 
                 lambda_1: float,
                 lambda_2: float,
                 eta: float,
                 alpha: float,
                 hypersphere,
                 model,
                 method,
                 device):
                 

        super().__init__()
        
        self.lambda_d = torch.tensor([lambda_1, lambda_2]).to(device) # 
        self.eta = torch.tensor([eta]).to(device)
        
        # svm penalty parameter 
        self.alpha = alpha
        
        self.hypersphere = hypersphere
        
        self.model = model
        
        self.method = method

        # encoder loss = hypersphere embedding + contrastive
        # contrastive loss
        self.contrastive_loss = ContrastiveLoss()
        # hypersphere embedding loss
        self.hypersphere_loss = HypersphereLoss()
        
        # classifier loss 
        #self.classif_loss = ClassifLoss()
        
        

    # cross entropy loss
    def comput_CE_loss(self, pre_value, labels: torch.Tensor):
        # labels: 1 x samples, each element is from {0,1,2, class_num - 1} 
        # classifier_outputs: samples x class_num
        pre_value = pre_value
        

        #pre_softmax = F.softmax(pre_value.detach(), dim=1)
        #pre_label = torch.argmax(pre_softmax, dim=1)
        pre_label = torch.argmax(pre_value, dim=1)
        
        criterion = nn.CrossEntropyLoss() 

        #loss and acc
        classif_loss = criterion(pre_value, labels.long()).mean()     

        acc = torch.sum(pre_label == labels.long()).float().mean() / len(labels)
         
        
        return classif_loss, acc
    
    
    def comput_CE_classifier_loss(self, classifier_outputs, labels: torch.Tensor):
        # labels: 1 x samples, each element is from {0,1,2, class_num - 1} 
        # classifier_outputs: samples x class_num
        
        pre_values = classifier_outputs["repre_classifier"]
        loss,acc = self.comput_CE_loss(pre_values, labels)
   
        
        ClassifLosses ={}
        ClassifLosses["classifer_loss"] = loss
        ClassifLosses["acc"] = acc
  
        
        return ClassifLosses
    
    

        
    # SVM objective function 
    def comput_hinge_loss(self, pre_values, labels):
        # acc
        # correct, if predict value and groundtruth are the same symbol; otherwise error
        acc = 0
        tmp_mul = pre_values.view(-1,1) * labels.view(-1,1)
        tmp_mul[tmp_mul>=0] = 1 # 1, same signs
        tmp_mul[tmp_mul<0] = 0 # 0, different signs
        acc = tmp_mul.sum() / (len(tmp_mul))
        
        # weights 
        classifier_model = self.model.repre_classifier
        last_weight = classifier_model.dense3.weight
        
        # L2 norm square： 0.5 * ||w||^2
        reg_weight = torch.norm(last_weight, p=2)
        reg_weight = 0.5 * reg_weight * reg_weight #.pow(2)
        

        # square hinge loss, sum(max(0, 1 - y * y')^2)
        #pre_y = pre_values.view(-1) * labels.view(-1)
        #pre_y = torch.mul(pre_values.view(-1), labels.view(-1))
        #pre_y = 1 - pre_y
        #pre_y[pre_y<0] = 0
        
        # clamp(min, max, para): para is in [min, max]
        pre_y = (1 - (pre_values.view(-1) * labels.view(-1))).clamp(0)
        pre_y = torch.sum(pre_y * pre_y)
        
        #pre_y = torch.mean(pre_y * pre_y)
        
        loss = reg_weight + self.alpha * pre_y

        return loss,acc    

    def comput_svm_classifier_loss(self, classifier_outputs, labels: torch.Tensor):
        # labels : bi-valued vector from {-1,1}    
        # classifier_outputs: real valued vector

        # predict
        pre_values = classifier_outputs["repre_classifier"]
        loss,acc = self.comput_hinge_loss(pre_values, labels)

        
        ClassifLosses ={}        
        ClassifLosses["classifer_loss"] = loss
        ClassifLosses["acc"] = acc

     
        return ClassifLosses
    
    # distance according to each row of matrices 
    def comput_Euclidean(self, pro_repre1, pro_repre2):
        # input : N x dim

        diff_pro = (pro_repre1 - pro_repre2) * (pro_repre1 - pro_repre2)
        diff_pro = diff_pro.sum(dim=1)
        
        return diff_pro      
    
    # positive-negative loss calculate
    def comput_PN_loss(self, H1, H2, idx_tuple, lambda_d):
        # the pairs distance and loss
        loss = {}
        # positive pairs: L2（H1 - H2）
        anchor_postive = self.comput_Euclidean(H1, H2)
        anchor_postive = anchor_postive.mean()
        loss['postive'] = anchor_postive.detach()

        # negative pairs: if anchor is from H1，L2(H1 - H1[a]), L2(H1-H2[a])
        anchorH1_negative = torch.cat([self.comput_Euclidean(H1, H2[idx_tuple]),
                                       self.comput_Euclidean(H1, H1[idx_tuple])], dim=0)
        loss['negative1'] = anchorH1_negative.mean().detach()
        # square hinge loss    
        anchorH1_negative = (lambda_d - anchorH1_negative).clamp(0)
        anchorH1_negative = anchorH1_negative * anchorH1_negative
        anchorH1_negative =  anchorH1_negative.mean()
        
        # negative pairs: if anchor is from H2，L2(H2 - H1[a]), L2(H2-H2[a])
        anchorH2_negative = torch.cat([self.comput_Euclidean(H2, H2[idx_tuple]),
                                       self.comput_Euclidean(H2, H1[idx_tuple])],dim=0)
        loss['negative2'] = anchorH2_negative.mean().detach()
        # square hinge loss        
        anchorH2_negative = (lambda_d - anchorH2_negative).clamp(0)
        anchorH2_negative = anchorH2_negative * anchorH2_negative        
        anchorH2_negative = anchorH2_negative.mean()
        
        loss['contrastive']= anchor_postive + anchorH1_negative + anchorH2_negative 
        
        return loss
    
    # up to date SMCL loss, calculating with similar matrix, running faster
    # instead of version-0 and -1 with 4-tuple loss
    def comput_contrastive_loss_v2(self, SMCL_outputs, miu_hypersphere,idx_tuple):
        # stage 1--encoder contrastive loss
        H1 = SMCL_outputs['project_stage1_v1']
        H2 = SMCL_outputs['project_stage1_v2']
        loss_stage1 = self.comput_PN_loss(H1, H2, idx_tuple, self.lambda_d[0])

        # --hypersphere constraint
        H1 = SMCL_outputs['output_stage1_v1']
        H2 = SMCL_outputs['output_stage1_v2']      
        pro_repre = torch.cat([H1,H2], dim=0)
        loss_stage1_shpere = self.hypersphere_loss(pro_repre, miu_hypersphere[0])
        
        
        # stage 2--encoder contrastive loss
        H1 = SMCL_outputs['project_stage2_v1']
        H2 = SMCL_outputs['project_stage2_v2']
        loss_stage2 = self.comput_PN_loss(H1, H2, idx_tuple,self.lambda_d[1])

        # --hypersphere constraint
        H1 = SMCL_outputs['output_stage2_v1']
        H2 = SMCL_outputs['output_stage2_v2']   
        pro_repre = torch.cat([H1,H2], dim=0)
        loss_stage2_shpere = self.hypersphere_loss(pro_repre, miu_hypersphere[1])
        
        # contrastive loss + eta * hypersphere loss
        # eta should be in 0.1 <= eta <= 1.0
        loss_total = loss_stage1["contrastive"] * 0.5 + \
                     loss_stage2["contrastive"] * 1.0 + \
                     loss_stage1_shpere["hypersphere_loss"] * self.eta * 0.5 + \
                     loss_stage2_shpere["hypersphere_loss"] * self.eta * 1.0

        SMCL_loss = {}
        SMCL_loss["stage1_postive"] = loss_stage1["postive"]
        SMCL_loss["stage1_negative1"] = loss_stage1["negative1"]
        SMCL_loss["stage1_negative2"] = loss_stage1["negative2"]
        SMCL_loss["stage1"] = loss_stage1["contrastive"]
        SMCL_loss["stage1_hypersphere"] = loss_stage1_shpere["hypersphere_loss"]

        SMCL_loss["stage2_postive"] = loss_stage2["postive"]
        SMCL_loss["stage2_negative1"] = loss_stage2["negative1"]
        SMCL_loss["stage2_negative2"] = loss_stage2["negative2"]
        SMCL_loss["stage2"] = loss_stage2["contrastive"]
        SMCL_loss["stage2_hypersphere"] = loss_stage2_shpere["hypersphere_loss"]
        
        
        SMCL_loss["loss"] = loss_total

        return SMCL_loss

    #Without HC, it is give up, because it is equal to that loss.eta=0
    def comput_contrastive_loss_v2_nonhypere(self, SMCL_outputs, miu_hypersphere,idx_tuple):
        # stage 1
        H1 = SMCL_outputs['project_stage1_v1']
        H2 = SMCL_outputs['project_stage1_v2']
        
        loss_stage1 = self.comput_PN_loss(H1, H2, idx_tuple, self.lambda_d[0])

        pro_repre = torch.cat([H1,H2], dim=0)
        loss_stage1_shpere = 0# self.hypersphere_loss(pro_repre, miu_hypersphere[0])
        
        
        # stage 2
        H1 = SMCL_outputs['project_stage2_v1']
        H2 = SMCL_outputs['project_stage2_v2']
        
        loss_stage2 = self.comput_PN_loss(H1, H2, idx_tuple,self.lambda_d[1])

        pro_repre = torch.cat([H1,H2], dim=0)
        loss_stage2_shpere = 0# self.hypersphere_loss(pro_repre, miu_hypersphere[1])
        
        # contrastive loss + eta * hypersphere loss
        # eta : 0.1 <= eta <= 1.0
        loss_total = loss_stage1["contrastive"] * 0.5 + \
                     loss_stage2["contrastive"] * 1.0 + \
                     loss_stage1_shpere["hypersphere_loss"] * self.eta * 0.5 + \
                     loss_stage2_shpere["hypersphere_loss"] * self.eta * 1.0

        SMCL_loss = {}
        SMCL_loss["stage1_postive"] = loss_stage1["postive"]
        SMCL_loss["stage1_negative1"] = loss_stage1["negative1"]
        SMCL_loss["stage1_negative2"] = loss_stage1["negative2"]
        SMCL_loss["stage1"] = loss_stage1["contrastive"]
        SMCL_loss["stage1_hypersphere"] = loss_stage1_shpere["hypersphere_loss"]

        SMCL_loss["stage2_postive"] = loss_stage2["postive"]
        SMCL_loss["stage2_negative1"] = loss_stage2["negative1"]
        SMCL_loss["stage2_negative2"] = loss_stage2["negative2"]
        SMCL_loss["stage2"] = loss_stage2["contrastive"]
        SMCL_loss["stage2_hypersphere"] = loss_stage2_shpere["hypersphere_loss"]
        
        
        SMCL_loss["loss"] = loss_total

        return SMCL_loss

    
    # tuple[anchor, postive,negative1,negative2],
    # contrastive loss with tuple, running slow
    def compute_contrastive_loss(self, SMCL_outputs, miu_hypersphere, tuple_pairs, anchors):
        if anchors=="v1":
            # stage 1
            # PH: positive pairs loss in project head
            anchor = SMCL_outputs['project_stage1_v1'][tuple_pairs[0]]
            positive = SMCL_outputs['project_stage1_v2'][tuple_pairs[1]]
            negative1 = SMCL_outputs['project_stage1_v1'][tuple_pairs[2]]
            negative2 = SMCL_outputs['project_stage1_v2'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0)           
            loss_stage1 = self.contrastive_loss(pro_repre, self.lambda_d)
            
            # encoder
            # hypersphere contraint: calculate in the end of the encoder network
            anchor = SMCL_outputs['output_stage1_v1'][tuple_pairs[0]]
            positive = SMCL_outputs['output_stage1_v2'][tuple_pairs[1]]
            negative1 = SMCL_outputs['output_stage1_v1'][tuple_pairs[2]]
            negative2 = SMCL_outputs['output_stage1_v2'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0)             
            loss_stage1_shpere = self.hypersphere_loss(pro_repre, miu_hypersphere[0])
            
            ############################################
            # stage 2
            anchor = SMCL_outputs['project_stage2_v1'][tuple_pairs[0]]
            positive = SMCL_outputs['project_stage2_v2'][tuple_pairs[1]]
            negative1 = SMCL_outputs['project_stage2_v1'][tuple_pairs[2]]
            negative2 = SMCL_outputs['project_stage2_v2'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0)           
            loss_stage2 = self.contrastive_loss(pro_repre, self.lambda_d) 
            
            # encoder
            anchor = SMCL_outputs['output_stage2_v1'][tuple_pairs[0]]
            positive = SMCL_outputs['output_stage2_v2'][tuple_pairs[1]]
            negative1 = SMCL_outputs['output_stage2_v1'][tuple_pairs[2]]
            negative2 = SMCL_outputs['output_stage2_v2'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0) 
            loss_stage2_shpere = self.hypersphere_loss(pro_repre, miu_hypersphere[1])
        
        elif anchors=="v2":
            # stage 1
            anchor = SMCL_outputs['project_stage1_v2'][tuple_pairs[0]]
            positive = SMCL_outputs['project_stage1_v1'][tuple_pairs[1]]
            negative1 = SMCL_outputs['project_stage1_v2'][tuple_pairs[2]]
            negative2 = SMCL_outputs['project_stage1_v1'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0)           
            loss_stage1 = self.contrastive_loss(pro_repre, self.lambda_d)
            
            # encoder
            anchor = SMCL_outputs['output_stage1_v2'][tuple_pairs[0]]
            positive = SMCL_outputs['output_stage1_v1'][tuple_pairs[1]]
            negative1 = SMCL_outputs['output_stage1_v2'][tuple_pairs[2]]
            negative2 = SMCL_outputs['output_stage1_v1'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0) 
            loss_stage1_shpere = self.hypersphere_loss(pro_repre, miu_hypersphere[0])
            
            # stage 2
            anchor = SMCL_outputs['project_stage2_v2'][tuple_pairs[0]]
            positive = SMCL_outputs['project_stage2_v1'][tuple_pairs[1]]
            negative1 = SMCL_outputs['project_stage2_v2'][tuple_pairs[2]]
            negative2 = SMCL_outputs['project_stage2_v1'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0)           
            loss_stage2 = self.contrastive_loss(pro_repre, self.lambda_d)
            
            # encoder
            anchor = SMCL_outputs['output_stage2_v2'][tuple_pairs[0]]
            positive = SMCL_outputs['output_stage2_v1'][tuple_pairs[1]]
            negative1 = SMCL_outputs['output_stage2_v2'][tuple_pairs[2]]
            negative2 = SMCL_outputs['output_stage2_v1'][tuple_pairs[3]]
            pro_repre = torch.stack([anchor,
                                     positive,
                                     negative1,
                                     negative2],dim=0) 
            loss_stage2_shpere = self.hypersphere_loss(pro_repre, miu_hypersphere[1])                
        
        # contrastive loss + eta * hypersphere loss
        # eta:0.1 <= eta <= 1.0
        loss_total = loss_stage1["contrastive"] * 1.0 + \
                     loss_stage2["contrastive"] * 1.0 + \
                     loss_stage1_shpere["hypersphere_loss"] * self.eta * 1.0 + \
                     loss_stage2_shpere["hypersphere_loss"] * self.eta * 1.0
                                                                   

        SMCL_loss = {}
        SMCL_loss["stage1_postive"] = loss_stage1["postive_pairs"]
        SMCL_loss["stage1_negative1"] = loss_stage1["negative_pairs1"]
        SMCL_loss["stage1_negative2"] = loss_stage1["negative_pairs2"]
        SMCL_loss["stage1"] = loss_stage1["contrastive"]
        SMCL_loss["stage1_hypersphere"] = loss_stage1_shpere["hypersphere_loss"]

        SMCL_loss["stage2_postive"] = loss_stage2["postive_pairs"]
        SMCL_loss["stage2_negative1"] = loss_stage2["negative_pairs1"]
        SMCL_loss["stage2_negative2"] = loss_stage2["negative_pairs2"]
        SMCL_loss["stage2"] = loss_stage2["contrastive"]
        SMCL_loss["stage2_hypersphere"] = loss_stage2_shpere["hypersphere_loss"]
        
        
        SMCL_loss["loss"] = loss_total

        return SMCL_loss






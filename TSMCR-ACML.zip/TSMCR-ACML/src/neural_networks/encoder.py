import torch
import torch.nn as nn
#from src.utils.custom_typing import EncoderOutput

# build a representation network with 3 Conv2d, 2 Bn, 1 relu, 1 Flatten, and 1 Dense  
class BaseEncoder(nn.Module):
    def __init__(
        self,
        in_size: int,
        in_channels: int,
        num_filters: int,
        kernel_size: int,
        repr_dim: int,
    ):
        """Encoder to extract the representations

        Args:
            in_size (int): [Image size (must be squared size)]
            in_channels (int): Number of input channels
            num_filters (int): Intermediate number of filters
            kernel_size (int): Convolution kernel size
            repr_dim (int): Dimension of the desired representation
        """
        super().__init__()
        
        # 
        self.dense1 = nn.Linear(in_features=in_size, out_features=repr_dim)
        self.bn1 = nn.BatchNorm1d(num_features=repr_dim)
        
        self.dense2 = nn.Linear(in_features=repr_dim, out_features=repr_dim)
        self.bn2 = nn.BatchNorm1d(num_features=repr_dim)
        
        self.dense3 = nn.Linear(in_features=repr_dim, out_features=repr_dim)
        self.drop = nn.Dropout(0.1)
        self.relu = nn.ReLU()
        
        self.dense4 = nn.Linear(in_features=repr_dim, out_features=repr_dim)


    def forward(self, x: torch.Tensor):
        """Forward encoder

        Args:
            x (torch.Tensor): data from a given domain

        Returns:
            EncoderOutput: Representation
        """
        x = self.dense1(x)
        x = self.bn1(x)
        
        x = self.dense2(x)
        x = self.bn2(x)

        x = self.dense3(x)
        x = self.drop(x)
        x = self.relu(x)
        
        representation = self.dense4(x)

        return representation



# =============================================================================
#         self.conv1 = nn.Conv2d(
#             in_channels=in_channels,
#             out_channels=num_filters * 2 ** 0,
#             kernel_size=kernel_size,
#             stride=1,
#         )
#         self.conv2 = nn.Conv2d(
#             in_channels=num_filters * 2 ** 0,
#             out_channels=num_filters * 2 ** 1,
#             kernel_size=kernel_size,
#             stride=2,
#         )
#         self.bn2 = nn.BatchNorm2d(num_features=num_filters * 2 ** 1)
#         self.conv3 = nn.Conv2d(
#             in_channels=num_filters * 2 ** 1,
#             out_channels=num_filters * 2 ** 2,
#             kernel_size=kernel_size,
#             stride=2,
#         )
#         self.bn3 = nn.BatchNorm2d(num_features=num_filters * 2 ** 2)
#         self.leaky_relu = nn.LeakyReLU()
# 
#         self.flatten = nn.Flatten()
# 
#         self.dense = nn.Linear(
#             in_features=(4 ** 2) * (num_filters * 2 ** 2),
#             out_features=repr_dim,
#         )
# =============================================================================
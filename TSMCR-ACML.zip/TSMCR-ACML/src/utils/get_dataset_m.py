import torch
import torch.nn.functional as F

from torchvision import datasets
from torchvision.transforms import ToTensor, Compose, Normalize
from torch.utils.data import Dataset

import random
import numpy as np
import copy
import os

import scipy.io as sio

from sklearn import preprocessing

from torch import Tensor


import numpy as np




class get_dataset_m(object):
    def __init__(self, train=True, data_folder="../data/data", val_fold=1, method='SMCL_svm'):
        
        
        self.val_fold = val_fold
        self.method = method

        # Please load your dataset with two views:
        # require-- B_data and E_data are N x dim matices
        #           label is 1-dim vector, which includes 1 and -1
        #           fold_index is 1-dim vector
        
        B_data = np.float32(np.random.rand(10,30))
        E_data = np.float32(np.random.rand(10,30))
        label = np.array([-1,-1,-1,-1,-1,1,1,1,1,1])
        fold_index = np.array([1,2,2,1,1,1,2,2,1,2]) 
        
        
        
        label[np.where(label==-1)] = 0 
        
        self.num_sample = len(label) # 
        self.in_dim_B = B_data.shape[1]#
        self.in_dim_E = E_data.shape[1]
        self.out_dim = 1
        
        # standard 
        mg_scaler = preprocessing.StandardScaler()
        B_data = mg_scaler.fit_transform(B_data)
        E_data = mg_scaler.fit_transform(E_data)
        
        fold_index = np.squeeze(fold_index)
        index_test = np.where(np.array(fold_index) == self.val_fold)
        
        
        
        self.train_data = {}
        self.train_data["v1"] = torch.from_numpy(np.delete(B_data, index_test, axis=0))
        self.train_data["v2"] = torch.from_numpy(np.delete(E_data, index_test, axis=0))
        self.train_data["label"] = torch.from_numpy(np.reshape(np.delete(label, index_test, 
                                                    axis=0),(-1,1)))
        self.train_data["label"] = torch.squeeze(self.train_data["label"])

        self.test_data = {}
        self.test_data["v1"] = torch.from_numpy(B_data[index_test])
        self.test_data["v2"] = torch.from_numpy(E_data[index_test])
        self.test_data["label"] = torch.from_numpy(np.reshape(label[index_test],(-1,1))).squeeze()
        
        # samples： num * dim
        # labels： num, 
    
    def get_data_dim(self):
        return self.in_dim_B, self.in_dim_E
    
    def get_out_dim(self):

            
        if "SVM" in self.method:
            out_dim = 1
        elif "CE" in self.method:
            out_dim = 2
            
        return out_dim
    
        
    # generate the negative sample index
    def gen_negative_idx(self, label):
        # find the groundtruth index 
        idx_postive = np.where(label==1)[0] 
        idx_negative = np.where(label==0)[0] 
        
        #tmp_sample = np.array(list(range(len(label)))).reshape(-1,1)
        
        # index requires that label[i] is not equal to label[a[i]],
        a = [idx_negative[np.random.randint(0,len(idx_negative))] 
             if label[i]==1 
             else idx_postive[np.random.randint(0, len(idx_postive))]
             for i in range(len(label))]
        
        
        return a
        
    # generate the positive sample index
    def get_pos_neg_idx(self, label):
        idx_postive = np.where(label==1) #torch.zeros_like(label)
        idx_negative = np.where(label==0) #torch.zeros_like(label)
        
        idx = {}
        idx["postive"] = idx_postive[0]#np.array(idx_postive)
        idx["negative"] = idx_negative[0]#np.array(idx_negative)
        return idx
    
    # given a label vector，generate the index of all tuples, 
    # tuple : [anchor, postive, negative, negative]
    def get_tuple(self, label):
        idx = []
        
        label_idx = self.get_pos_neg_idx(label)
        for i in range(len(label)):
            anchor = i
            postive = i
            
            if label[i]==1:
                tmp_idx = torch.randint(0, np.size(label_idx["negative"]),(1,))
                negative = label_idx["negative"][tmp_idx[0]]
                
            else:
                tmp_idx = torch.randint(0, np.size(label_idx["postive"]),(1,))
                negative = label_idx["postive"][tmp_idx[0]]
                
            
            tuple_pairs = [anchor, postive, negative, negative]
            
            idx.append(tuple_pairs)
            
        return idx


    def get_tuple_SimCLR(self, label):
        idx = []
        

        idx_all = list(range(len(label)))
        for i in range(len(label)):
            anchor = i
            postive = i
            
            negative = copy.deepcopy(idx_all)
            del(negative[i])

            tuple_pairs = [anchor, postive, negative]
            
            idx.append(tuple_pairs)
            
        return idx

    
    def label_change(self, label, method):
        # h_target to long
        h_target = label.view(-1,1).type(torch.long)
        # one-hot
        # num_classes = len(torch.unique(h_target)) #2
        # y = h_target            
        # h_target = torch.squeeze(torch.eye(num_classes)[y]).float()
        if "CE" in method:# == 'SMCL_CE':
            h_target = torch.squeeze(h_target)

        elif "SVM" in method:# == 'SMCL_SVM':
            # label vector with [-1，1]
            h_target[h_target!=1]=-1    
            
        return h_target
 

    # shuffle
    def shuffle_data(self, len_data):
        idx = torch.randperm(len_data)
        return idx
        
    def get_train_data(self):
        idx = self.shuffle_data(len(self.train_data["label"]))
        
        train_data = {}
        train_data["v1"] = self.train_data["v1"][idx,:]
        train_data["v2"] = self.train_data["v2"][idx,:]
        train_data["label"] = self.train_data["label"][idx]
        
        return train_data
    
    
    def get_test_data(self):
        test_data = {}
        test_data["v1"] = self.test_data["v1"]
        test_data["v2"] = self.test_data["v1"]
        test_data["label"] = self.test_data["label"]
        
        return test_data
  
    
    def get_data_info(self):
        info_data = {}
        info_data["tr_num"] = self.train_data["v1"].size(0)
        info_data["te_num"] = self.test_data["v1"].size(0)
        info_data["v1_dim"] = self.train_data["v1"].size(1)
        info_data["v2_dim"] = self.train_data["v2"].size(1)
        
        return info_data
    
    
    # batch index 
    def get_batch_train(self, batch_size):
        
        num_train = self.train_data["label"].size(0)
        num_batch = num_train // batch_size
        dataloader_indx = []
        
        for i in range(num_batch):
            start_indx = i * batch_size
            end_indx = (i + 1) * batch_size -1

            dataloader_indx.append([start_indx, end_indx])
        
        # remaining data to last batch
        if num_train % batch_size != 0:
            dataloader_indx.append([num_batch * batch_size, num_train])
            
        return dataloader_indx
    
    
    # batch index of test
    # if using small sample, batch size is larger than the number of each fold sample 
    def get_batch_test(self, batch_size):
        
        num_test = self.test_data["label"].size(0)
        num_batch = num_test // batch_size
        dataloader_indx = []
        
        for i in range(num_batch):
            start_indx = i * batch_size
            end_indx = (i + 1) * batch_size -1

            dataloader_indx.append([start_indx, end_indx])
        
        # remaining data to last batch 
        if num_test % batch_size != 0:
            dataloader_indx.append([num_batch * batch_size, num_test])
            
        return dataloader_indx
    


# -*- coding: utf-8 -*-
"""
Created on Tue Jun 13 09:39:12 2023

@author: gbm
"""

import sys
import os

#my_cwd = os.getcwd()
my_cwd = os.path.abspath(os.path.join(os.getcwd(),'..'))
# 
def add_mypath():
    if my_cwd not in sys.path:
        sys.path.append(my_cwd)
        
        new_path = os.path.join(my_cwd, 'src')
        sys.path.append(new_path)
        
        new_path = os.path.join(new_path, 'utils')
        sys.path.append(new_path)
        
        
if __name__ == "__main__":
    add_mypath()
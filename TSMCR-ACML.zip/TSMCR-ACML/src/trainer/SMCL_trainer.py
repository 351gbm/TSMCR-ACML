import time
import torch.optim as optim
import torch
import torch.nn as nn
#from torch.utils.tensorboard import SummaryWriter



from torch.utils.data.dataloader import DataLoader
from torch.utils.data import Dataset
from tqdm import tqdm
import mlflow
import mlflow.pytorch as mpy

import numpy as np

from src.utils.get_dataset_m import get_dataset_m

import scipy.io as scio

class SMCLTrainer:
    def __init__(
        self,
        model,
        loss,
        load_dataset,
        learning_rate,
        batch_size,
        device,
        fold,
        method,
    ):
        """Rich representation via supervised multi-views contrastive learning trainer

        Args:
            model (SMCL): SMCL encoder and classifier
            loss (SMCLLoss): conrastive and classifier loss
            dataset_train (Dataset): Train dataset
            learning_rate (float): Learning rate
            batch_size (int): Batch size
            device (str): Device among cuda/cpu
        """
        self.load_dataset = load_dataset
        
        # 
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        
        self.model = model.to(device)
        self.loss = loss
        self.device = device
        
        self.fold = fold
        
        self.method = method

        
        # optimizer
        # stage 1--encoder 
        self.optimizer_enc_stage1_v1 = optim.Adam(self.model.SMCL_enc_stage1_v1.parameters(),
                                                  lr=self.learning_rate
                                                  )
        
        self.optimizer_enc_stage1_v2 = optim.Adam(self.model.SMCL_enc_stage1_v2.parameters(),
                                                  lr=self.learning_rate)
        
        # projection head
        self.optimizer_PH_stage1_v1 = optim.Adam(self.model.SMCL_PH_stage1_v1.parameters(),
                                                lr=self.learning_rate)
        self.optimizer_PH_stage1_v2 = optim.Adam(self.model.SMCL_PH_stage1_v2.parameters(),
                                                 lr=self.learning_rate)
        
        
        # stage 2--encoder
        self.optimizer_enc_stage2 = optim.Adam(self.model.SMCL_enc_stage2.parameters(),
                                               lr=self.learning_rate)
        
        # projection head
        self.optimizer_PH_stage2 = optim.Adam(self.model.SMCL_PH_stage2.parameters(),
                                              lr=self.learning_rate)
        
        # classifier
        self.optimizer_classifier = optim.Adam(self.model.repre_classifier.parameters(),
                                               lr=self.learning_rate)     
              
   
                 

    def gradient_zero(self):
        """Set all the networks gradient to zero"""
        self.optimizer_enc_stage1_v1.zero_grad()
        self.optimizer_enc_stage1_v2.zero_grad()

        self.optimizer_PH_stage1_v1.zero_grad()
        self.optimizer_PH_stage1_v2.zero_grad()

        self.optimizer_enc_stage2.zero_grad()
        self.optimizer_PH_stage2.zero_grad()


    def gradient_step(self):
        """Make an optimisation step for all the networks"""
        self.optimizer_enc_stage1_v1.step()
        self.optimizer_enc_stage1_v2.step()

        self.optimizer_PH_stage1_v1.step()
        self.optimizer_PH_stage1_v2.step()

        self.optimizer_enc_stage2.step()
        self.optimizer_PH_stage2.step()


    # update classifier
    def update_classifier(self, v1, v2, labels):
        # modified lable vector according to method
        h_target = self.load_dataset.label_change(labels, self.method)
        h_target = h_target.to(self.device)
        
        SMCL_outputs = self.model.forward_encoder(v1, v2)
        
        classif_outputs = self.model.forward_classifier(SMCL_outputs)
        
        # optimization 
        self.optimizer_classifier.zero_grad()



        if "SVM" in self.method: 
            losses = self.loss.comput_svm_classifier_loss(classifier_outputs=classif_outputs, 
                                                      labels=h_target)
        elif "CE" in self.method:
            losses = self.loss.comput_CE_classifier_loss(classifier_outputs=classif_outputs, 
                                                      labels=h_target)            
        else:
            print("ERROR: classifiers")
            

        losses["classifer_loss"].backward()
        
        self.optimizer_classifier.step()

        
        return losses
  
    # calculate hypersphere radius (the mean of representation L2-norm),
    # forcing all samples near to the same hypersphere surface 
    def comput_miu(self, SMCL_outputs):
        #stage 1
        miu_stage1 = 0
        stage1_v1 = SMCL_outputs["output_stage1_v1"].detach()  # N * hiddens
        stage1_v2 = SMCL_outputs["output_stage1_v2"].detach()
        
        tmp_s1v1 = torch.norm(stage1_v1, dim=1)
        tmp_s1v2 = torch.norm(stage1_v2, dim=1)
        
        miu_stage1 = (torch.mean(tmp_s1v1) + torch.mean(tmp_s1v2)) / 2
        
        # stage 2
        miu_stage2 = 0
        stage2_v1 = SMCL_outputs["output_stage2_v1"].detach()  # N * hiddens
        stage2_v2 = SMCL_outputs["output_stage2_v2"].detach()
        
        tmp_v1 = torch.norm(stage2_v1, dim=1)
        tmp_v2 = torch.norm(stage2_v2, dim=1)
        
        miu_stage2 = (torch.mean(tmp_v1) + torch.mean(tmp_v2)) / 2        
        
        # return results
        return [miu_stage1, miu_stage2]
    

        
    #   
    def update_SMCL(self,v1,v2,labels):
        #  v1, v2: num * dim
        # labels: num vector,  each element is from {0,1}
        
        SMCL_outputs = self.model.forward_encoder(v1, v2)        
        
        # generate the index of tuple with labels information
        # idx_tuple: len(labels) x 4
        if self.device=='cuda':
            tmp_labels = labels.cpu()
        else:
            tmp_labels = labels
        idx_tuple = self.load_dataset.gen_negative_idx(tmp_labels) 
        
        
        self.gradient_zero()
        
        # hypershphere radius
        # list: 2 elements
        miu_hypersphere = self.comput_miu(SMCL_outputs)
        

        # noting: without HC, if loss.eta=0
        loss_CL = self.loss.comput_contrastive_loss_v2(SMCL_outputs,
                                                       miu_hypersphere,
                                                       idx_tuple)
        
        loss_CL["loss"].backward()
        

        #with torch.autograd.set_detect_anomaly(True):
        #    loss_all.backward(retain_graph=True)

        self.gradient_step()
                
        SMCL_losses = {}
        SMCL_losses["stage1_postive"] = loss_CL["stage1_postive"]
        SMCL_losses["stage1_negative1"] = loss_CL["stage1_negative1"]
        SMCL_losses["stage1_negative2"] = loss_CL["stage1_negative2"]
        SMCL_losses["stage1"] = loss_CL["stage1"]
        SMCL_losses["stage1_hypersphere"] = loss_CL["stage1_hypersphere"] # loss
        SMCL_losses["stage1_miu"] = miu_hypersphere[0] # 超球面半径

        SMCL_losses["stage2_postive"] = loss_CL["stage2_postive"]
        SMCL_losses["stage2_negative1"] = loss_CL["stage2_negative1"]
        SMCL_losses["stage2_negative2"] = loss_CL["stage2_negative2"]
        SMCL_losses["stage2"] = loss_CL["stage2"]
        SMCL_losses["stage2_hypersphere"] = loss_CL["stage2_hypersphere"]
        SMCL_losses["stage2_miu"] = miu_hypersphere[1]
        
        SMCL_losses["loss"] = loss_CL["loss"]
        SMCL_losses["loss_contrastive"] = loss_CL["stage1"] + loss_CL["stage2"]
        SMCL_losses["loss_hypersphere"] = loss_CL["stage1_hypersphere"] + loss_CL["stage2_hypersphere"]        
  
        return SMCL_losses       
            
    # model training, first SMCL, and then  DSVM fine tuning
    def train(self, epochs, xp_name="test"):
        """Trained SMCL and log losses and accuracy on Mlflow.

        Args:
            epochs (int): Number of epochs
            xp_name (str, optional): Name of the Mlfow experiment. Defaults to "test".
        """
        
        train_data = self.load_dataset.get_train_data()
        train_batch_indx = self.load_dataset.get_batch_train(self.batch_size)

        # results folder, set name
        mlflow.set_tracking_uri('./ml_save/'+ self.method +'/')
        xp_name = xp_name + '_fold' + str(self.fold)
        
        mlflow.set_experiment(experiment_name=xp_name)
        with mlflow.start_run() as run:

            log_params = {"Batchsize": self.batch_size,
                         "Learning rate": self.learning_rate,
                         "Alpha": self.loss.alpha,
                         "lambda_d": self.loss.lambda_d,
                         "eta": self.loss.eta,
                         }
            mlflow.log_params(log_params)

                    
            ######################################        
            # encoder --training iter
            log_step = 0
            for epoch in tqdm(range(epochs)):
                for idx, sample_idx  in enumerate(train_batch_indx):
                    
                    # load data
                    sample = {}
                    sample["v1"] = train_data["v1"][sample_idx[0]:sample_idx[1]+1,:]
                    sample["v2"] = train_data["v2"][sample_idx[0]:sample_idx[1]+1,:]
                    sample["label"] = train_data["label"][sample_idx[0]:sample_idx[1]+1]
                
                    # update SMCL
                    losses_SMCL = self.update_SMCL(sample["v1"].to(self.device),
                                                    sample["v2"].to(self.device),
                                                    sample["label"].to(self.device)
                                                    )

                    # SMCL logging
                    dict_SMCL = losses_SMCL#[-1]
                    mlflow.log_metrics(
                        {k: v.item() for k, v in dict_SMCL.items()}, step=log_step
                        )

                    log_step += 1

            # save model (model)
            mpy.log_state_dict(self.model.state_dict(), 'Encoder_'+self.method)  


            
            # classifier--training iter        
            log_step = 0
            for epoch in tqdm(range(epochs)):
                for idx, sample_idx  in enumerate(train_batch_indx):
                    
                    # load data
                    sample = {}
                    sample["v1"] = train_data["v1"][sample_idx[0]:sample_idx[1]+1,:]
                    sample["v2"] = train_data["v2"][sample_idx[0]:sample_idx[1]+1,:]
                    sample["label"] = train_data["label"][sample_idx[0]:sample_idx[1]+1]
                
                    
                    # update classifier
                    losses_classifer = self.update_classifier(sample["v1"].to(self.device),
                                                              sample["v2"].to(self.device),
                                                              sample["label"].to(self.device)
                                                              )
                    
                    # classifer logging
                    dict_classifer = losses_classifer
                    mlflow.log_metrics(
                          {k: v.item() for k, v in dict_classifer.items()}, step=log_step
                          )
                    

                    log_step += 1  
                    

            ######################################################

            # save model (optional)
            mpy.log_state_dict(self.model.state_dict(), self.method)  


            
    # Alternate training
    def train_alternate(self, epochs, xp_name="test"):
        """Trained SMCL and log losses and accuracy on Mlflow.

        Args:
            epochs (int): Number of epochs
            xp_name (str, optional): Name of the Mlfow experiment. Defaults to "test".
        """
        
        train_data = self.load_dataset.get_train_data()
        train_batch_indx = self.load_dataset.get_batch_train(self.batch_size)

        print('training with alternate: ')
        # results folder and save 
        mlflow.set_tracking_uri('./ml_save/'+ self.method +'/')
        xp_name = xp_name + '_fold' + str(self.fold)
        
        mlflow.set_experiment(experiment_name=xp_name)
        with mlflow.start_run() as run:

            log_params = {"Batchsize": self.batch_size,
                         "Learning rate": self.learning_rate,
                         "Alpha": self.loss.alpha,
                         "lambda_d": self.loss.lambda_d,
                         "eta": self.loss.eta,
                         }
            mlflow.log_params(log_params)

                    
            ######################################        
            # encoder --training iter
            log_step = 0
            for epoch in tqdm(range(epochs)):
                for idx, sample_idx  in enumerate(train_batch_indx):
                    
                    # load data
                    sample = {}
                    sample["v1"] = train_data["v1"][sample_idx[0]:sample_idx[1]+1,:]
                    sample["v2"] = train_data["v2"][sample_idx[0]:sample_idx[1]+1,:]
                    sample["label"] = train_data["label"][sample_idx[0]:sample_idx[1]+1]
                
                    # update SMCL, forward and loss calculate 
                    losses_SMCL = self.update_SMCL(sample["v1"].to(self.device),
                                                    sample["v2"].to(self.device),
                                                    sample["label"].to(self.device)
                                                    )

                    # SMCL logging
                    # SMCL loss
                    dict_SMCL = losses_SMCL#[-1]
                    mlflow.log_metrics(
                        {k: v.item() for k, v in dict_SMCL.items()}, step=log_step
                        )


                    # update classifier 
                    losses_classifer = self.update_classifier(sample["v1"].to(self.device),
                                                              sample["v2"].to(self.device),
                                                              sample["label"].to(self.device)
                                                              )
                    
                    # classifier logging
                    dict_classifer = losses_classifer
                    mlflow.log_metrics(
                          {k: v.item() for k, v in dict_classifer.items()}, step=log_step
                          )
                    

                    log_step += 1  
                    
        ######################################################


            
            # save model (optional)
            mpy.log_state_dict(self.model.state_dict(), 'Encoder_'+self.method)  

            
            # save model (optional)
            mpy.log_state_dict(self.model.state_dict(), self.method)  

            

                         
            





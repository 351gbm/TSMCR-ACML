import argparse
import numpy as np
import os

#os.environ["GIT_PYTHON_REFRESH"] = "quiet"
from add_mypath import add_mypath
    
add_mypath()

import random
import torch
import torch.nn as nn
import glob
import ruamel.yaml as yaml

from src.models.SMCL import SMCL
from src.losses.SMCL_loss import SMCLLoss
from src.trainer.SMCL_trainer import SMCLTrainer


#from src.utils.colored_mnist_dataloader import ColoredMNISTDataset

from src.utils.get_dataset_m import get_dataset_m

# maybe you need to install the package by conda
#conda install ruamel.yaml 


#%%
def run(
    xp_name: str,
    conf_path: str,
    data_base_folder: str,
    seed: int = None,
):
    # set seed 
    with open(conf_path, "r") as f:
        conf = yaml.safe_load(f)
    if seed is not None:
        seed = seed
        random.seed(seed)
        os.environ["PYTHONHASHSEED"] = str(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.cuda.manual_seed_all(seed)

    TRAINING_METHOD = conf["method"]
    TRAINING_PARAM = conf["training_param"]
    MODEL_PARAM = conf["model_param"]
    LOSS_PARAM = conf["loss_param"]
    FOLD_PARAM = conf["fold_param"]
    
    # dataset building
    # val_fold--validation set index，train and test dataset includes two views 
    val_fold = FOLD_PARAM["fold"] #
    load_dataset = get_dataset_m(train=True, 
                                 data_folder=data_base_folder, 
                                 val_fold = val_fold,
                                 method = TRAINING_METHOD
                                 )


    # creat SMCL model (supervised multi-views contrastive learning)
    in_size_v1, in_size_v2 = load_dataset.get_data_dim()
    classifier_dim = load_dataset.get_out_dim()
    model = SMCL(in_size_v1=in_size_v1,
                 in_size_v2=in_size_v2,
                 stage1_hidden = MODEL_PARAM["stage1_hidden"],
                 stage2_hidden = MODEL_PARAM["stage2_hidden"],
                 stage1_last = MODEL_PARAM["stage1_last"],
                 stage2_last = MODEL_PARAM["stage2_last"],
                 project_head = MODEL_PARAM["project_head"],
                 n_layers = MODEL_PARAM["n_layers"],
                 data_code = MODEL_PARAM["data_name"],
                 method = TRAINING_METHOD,
                 classifier_dim = classifier_dim,
                 )

    device = TRAINING_PARAM["device"]
    
    # Loss: contrastive + hypersphere + classifier
    loss = SMCLLoss(lambda_1 = LOSS_PARAM["lambda_1"],
                    lambda_2 = LOSS_PARAM["lambda_2"],
                    eta = LOSS_PARAM["eta"],
                    alpha = LOSS_PARAM["alpha"],
                    hypersphere=LOSS_PARAM["hypersphere"],
                    model = model,
                    method = TRAINING_METHOD,
                    device = device,
                    )
    
    print("fold",FOLD_PARAM["fold"],'Method: ',TRAINING_METHOD)
    print(LOSS_PARAM["lambda_1"],LOSS_PARAM["eta"],LOSS_PARAM["alpha"],MODEL_PARAM["stage1_hidden"])
    
    # 
    learning_rate = TRAINING_PARAM["learning_rate"]
    batch_size = TRAINING_PARAM["batch_size"]
    epochs = TRAINING_PARAM["epochs"]
    trainer = SMCLTrainer(model,
                          loss,
                          load_dataset,
                          learning_rate,
                          batch_size,
                          device,
                          val_fold,
                          method = TRAINING_METHOD,
                          )
    #trainer.train_alternate(epochs=epochs, xp_name=xp_name)
    trainer.train(epochs=epochs, xp_name=xp_name)
    
    

#%%
if __name__ == "__main__":    
    parser = argparse.ArgumentParser(
        description="Rich Representations via Supervised Multi-views Contrastive Learning"
    )
    parser.add_argument(
        "--xp_name",
        type=str,
        default="Contrastive_training",
        help="Mlflow experiment name",
    )
    parser.add_argument(
        "--conf_path", type=str, default="../conf/SMCL_conf.yaml", 
        help="Configuration file"
    )
    parser.add_argument(
        "--data_base_folder", type=str, default="../data/data", help="Data folder"
    )
    parser.add_argument("--seed", type=int, default=999, help="Random seed")

    args = parser.parse_args()
    xp_name = args.xp_name
    conf_path = args.conf_path
    data_base_folder = args.data_base_folder
    seed = args.seed

    print("Start rich representation training")
    run(
        xp_name=xp_name,
        conf_path=conf_path,
        data_base_folder=data_base_folder,
        seed=seed,
    )
    

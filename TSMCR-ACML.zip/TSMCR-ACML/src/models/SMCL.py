import torch
import torch.nn as nn
import torch.nn.functional as F

from src.neural_networks.classifier import Classifier
from src.models.block import get_primative_block, makeblock_dense  

# encoder module 
class ModelEncoder(nn.Module):
    def __init__(self,
                 in_width = 64,
                 hidden_width=64,
                 out_width=None,
                 n_layers=1, 
                 atype='relu',
                 model_type='simple-dense', 
                 data_code='mnist', 
                 **kwargs):
        super(ModelEncoder, self).__init__()
    
        self.in_width = in_width
        
        block_list = []
        
        # the node number of the last layer
        last_hw = hidden_width
        if out_width:
            last_hw = out_width
        
        # creat layers 
        for i in range(n_layers):
            block = get_primative_block('simple-dense', hidden_width, hidden_width, 
                                        atype)
            block_list.append(block)

        # channel number 
        in_ch = 1 #

        # initialize all layers (input,hidden,output) 
        self.input_layer    = makeblock_dense(in_width*in_ch, hidden_width, atype)
        self.sequence_layer = nn.Sequential(*block_list)
        self.output_layer   = makeblock_dense(hidden_width, last_hw, atype)


    def forward(self, x):
         
        # output list
        output_list = []
        
        # reshape x according to the given colums
        #x = x.view(-1, self.in_width)
        x = self.input_layer(x)
        output_list.append(x)
        
        # 
        for block in self.sequence_layer:
            x = block(x)
            output_list.append(x)
        
        # output layer
        x = self.output_layer(x)
        
        #x = F.normalize(x,dim=1)
        
        output_list.append(x)

        # return representation 
        return x, output_list


# linear mapping
class ModelProject(nn.Module):
    def __init__(self, in_width=71,
                 head='linear', 
                 project_head=int):
        super(ModelProject, self).__init__()
        
        if head == 'linear':
            self.head = nn.Linear(in_width, project_head)
        elif head == 'mlp':
            self.head = nn.Sequential(
                nn.Linear(in_width, in_width),
                nn.ReLU(inplace=False),
                nn.Linear(in_width, project_head)
            )
        else:
            raise NotImplementedError(
                'head not supported: {}'.format(head))
            
            
        # batch norm:0-mean, 1-var(optional)      
        # self.bn1 = nn.BatchNorm1d(num_features=project_head) 

    def forward(self, x):
        #x = x.detach() # 20230608
        pro = self.head(x)
        # z/||z|| 
        # if using HC, you can remove it
        pro = F.normalize(pro, dim=1)  
        return pro
    
    
    
    
class SMCL(nn.Module):
    def __init__(self, 
                 in_size_v1: int,
                 in_size_v2: int,
                 stage1_hidden: int,
                 stage2_hidden: int,
                 stage1_last: int,
                 stage2_last: int,
                 project_head: int,
                 n_layers: int,
                 data_code: str,
                 method: str,
                 classifier_dim: int):
        """Rich respresentation via supervised multi-views contrastive learning
        
        encoder + projection head + classifier

        Args:
            in_size (int): input vector size 
        """
        super().__init__()

        self.in_size_v1 = in_size_v1
        self.in_size_v2 = in_size_v2
        
        # tow-stage encoder with the same node numbers for different views
        self.stage1_hidden = stage1_hidden
        self.stage2_hidden = stage2_hidden
        
        self.stage1_last = stage1_last
        self.stage2_last = stage2_last
        
        #project head with the same node
        self.project_head = project_head
        
        # hidden layer numbers
        self.n_layers = n_layers
        
        # data name
        self.data_code = data_code
        
        self.method = method
        self.classifier_dim = classifier_dim
        
        ############################
        # Stage1 encoder with pseudo-siamese network
        self.SMCL_enc_stage1_v1 = ModelEncoder(in_width=self.in_size_v1,
                                       hidden_width = self.stage1_hidden,
                                       out_width = self.stage1_last,
                                       n_layers=self.n_layers,
                                       atype='linear',
                                       model_type='simple-dense',
                                       data_code='breast_cancer'
                                       )
        
        self.SMCL_enc_stage1_v2 = ModelEncoder(in_width=self.in_size_v2,
                                       hidden_width=self.stage1_hidden,
                                       out_width = self.stage1_last,
                                       n_layers=self.n_layers,
                                       atype='linear',
                                       model_type='simple-dense',
                                       data_code='breast_cancer'
                                       )        

        # Stage1 projection head 
        self.SMCL_PH_stage1_v1 = ModelProject(in_width=self.stage1_hidden,
                                              head='linear', 
                                              project_head=self.project_head
                                              )
        
        self.SMCL_PH_stage1_v2 = ModelProject(in_width=self.stage1_hidden,
                                              head='linear', 
                                              project_head=self.project_head
                                              )

        # Stage2 encoder with siamese network
        self.SMCL_enc_stage2 = ModelEncoder(in_width=self.stage1_last,
                                       hidden_width=self.stage2_hidden,
                                       out_width=self.stage2_last,
                                       n_layers=self.n_layers,
                                       atype='relu',
                                       model_type='simple-dense',
                                       data_code='breast_cancer'
                                       )
        
        # Stage2 projection head
        self.SMCL_PH_stage2 = ModelProject(in_width=self.stage2_hidden,
                                           head='linear',
                                           project_head=self.project_head
                                           )
        
        # Classifier
        # input dim equals twice the sum of two-satge encod output 
        # if classification with CE loss, output_dim=2; 
        # if classification with SVM hinge loss, output_dim=1
        cat_dim = 2*(self.stage1_last + self.stage2_last)
        self.repre_classifier = Classifier(feature_dim=cat_dim,
                                           output_dim=self.classifier_dim,
                                           units=cat_dim // 2
                                           )       
        
        
   

    def forward_encoder(self, v1, v2): 
        # input--v1 v2
        #v1: torch.Tensor, v2: torch.Tensor

        # stage1-encoder
        output_stage1_v1, output_list_stage1_v1 = self.SMCL_enc_stage1_v1(v1) 
        output_stage1_v2, output_list_stage1_v2 = self.SMCL_enc_stage1_v2(v2) 

        # projection
        project_stage1_v1 = self.SMCL_PH_stage1_v1(output_stage1_v1)
        project_stage1_v2 = self.SMCL_PH_stage1_v2(output_stage1_v2)
        
        # stage2-encoder
        # detach
        output_stage2_v1, output_list_stage2_v1 = self.SMCL_enc_stage2(output_stage1_v1.detach()) 
        output_stage2_v2, output_list_stage2_v2 = self.SMCL_enc_stage2(output_stage1_v2.detach())

        # projection
        project_stage2_v1 = self.SMCL_PH_stage2(output_stage2_v1)
        project_stage2_v2 = self.SMCL_PH_stage2(output_stage2_v2)        
    
        # representation 
        SMCL_outputs = {}
        SMCL_outputs['output_stage1_v1'] = output_stage1_v1
        SMCL_outputs['output_stage1_v2'] = output_stage1_v2
        SMCL_outputs['output_list_stage1_v1'] = output_list_stage1_v1
        SMCL_outputs['output_list_stage1_v2'] = output_list_stage1_v2
        
        SMCL_outputs['project_stage1_v1'] = project_stage1_v1
        SMCL_outputs['project_stage1_v2'] = project_stage1_v2
        
        SMCL_outputs['output_stage2_v1'] = output_stage2_v1
        SMCL_outputs['output_stage2_v2'] = output_stage2_v2
        SMCL_outputs['output_list_stage2_v1'] = output_list_stage2_v1
        SMCL_outputs['output_list_stage2_v2'] = output_list_stage2_v2
        
        SMCL_outputs['project_stage2_v1'] = project_stage2_v1
        SMCL_outputs['project_stage2_v2'] = project_stage2_v2
        
        return SMCL_outputs
    
    # clasification     
    def forward_classifier(self, SMCL_outputs):
        classifier_input = SMCL_outputs
         
        input_repre = torch.cat([classifier_input["output_stage1_v1"],
                                 classifier_input["output_stage1_v2"],
                                 classifier_input["output_stage2_v1"],
                                 classifier_input["output_stage2_v2"],
                                 ],
                                dim=1)#.detach()        
        repre_classifier = self.repre_classifier(input_repre)
        

        
        classifier_outputs = {}
        classifier_outputs["repre_classifier"] = repre_classifier

        
        return classifier_outputs
        
        
        
